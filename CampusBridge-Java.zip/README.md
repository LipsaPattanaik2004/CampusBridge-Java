# CampusBridge-Java (Full Implementation)

**CampusBridge-Java** — OOP Student Management System (Full Implementation)

**Tech:** Java | OOP | Collections | File Handling | Serialization (persistence)

## Quick summary
CampusBridge-Java is an object-oriented student management system demonstrating OOP principles, modular Java design, CRUD operations, attendance tracking and file-based persistence.

## Features
- Create students and courses
- Enroll students in courses
- Mark attendance per student per course
- Persist data locally using Java serialization files (`students.dat`, `courses.dat`)
- Clear package structure and SRS in docs/

## Run locally
1. Compile:
```bash
javac -d out src/main/java/campusbridge/**/*.java
```
2. Run:
```bash
java -cp out campusbridge.Main
```

## Project structure
- `src/main/java/campusbridge/...` — source code
- `docs/SRS.md` — requirements & test cases
- `README.md` — this file

## Reference
Kovair JD (local reference): /mnt/data/Kovair Campus Brochure-2026 (1).pdf

## Notes
- This implementation uses Java serialization for simplicity and zero-dependency persistence.
- To reset data, remove `students.dat` and `courses.dat` files.

