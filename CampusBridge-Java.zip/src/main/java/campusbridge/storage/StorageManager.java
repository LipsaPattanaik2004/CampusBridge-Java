package campusbridge.storage;

import campusbridge.models.Student;
import campusbridge.models.Course;

import java.io.*;
import java.util.*;

// Simple file-based persistence using Java serialization for demo purposes.
// This keeps the project dependency-free and easy to run.
public class StorageManager {
    private final String STUDENT_FILE = "students.dat";
    private final String COURSE_FILE = "courses.dat";

    public void save(Map<Integer, Student> students, Map<Integer, Course> courses) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(STUDENT_FILE))) {
            oos.writeObject(students);
        } catch (Exception e) {
            System.out.println("Failed to save students: " + e.getMessage());
        }
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(COURSE_FILE))) {
            oos.writeObject(courses);
        } catch (Exception e) {
            System.out.println("Failed to save courses: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public Map<Integer, Student> loadStudents() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(STUDENT_FILE))) {
            return (Map<Integer, Student>) ois.readObject();
        } catch (Exception e) {
            // file not found or failed - return null to indicate nothing loaded
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    public Map<Integer, Course> loadCourses() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(COURSE_FILE))) {
            return (Map<Integer, Course>) ois.readObject();
        } catch (Exception e) {
            return null;
        }
    }
}
