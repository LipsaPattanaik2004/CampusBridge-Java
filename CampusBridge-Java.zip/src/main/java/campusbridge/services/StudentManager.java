package campusbridge.services;

import campusbridge.models.Student;
import campusbridge.models.Course;
import campusbridge.storage.StorageManager;

import java.util.*;

public class StudentManager {
    private Map<Integer, Student> students = new HashMap<>();
    private Map<Integer, Course> courses = new HashMap<>();
    private StorageManager storage = new StorageManager();

    public void addStudent(Student s) {
        if (students.containsKey(s.getId())) {
            System.out.println("Student already exists.");
            return;
        }
        students.put(s.getId(), s);
        System.out.println("Student added: " + s.getName());
    }

    public void addCourse(Course c) {
        if (courses.containsKey(c.getId())) {
            System.out.println("Course already exists.");
            return;
        }
        courses.put(c.getId(), c);
        System.out.println("Course added: " + c.getName());
    }

    public void enrollStudentInCourse(int studentId, int courseId) {
        Student s = students.get(studentId);
        Course c = courses.get(courseId);
        if (s == null || c == null) {
            System.out.println("Student or course not found.");
            return;
        }
        s.enroll(c);
        System.out.println("Enrolled " + s.getName() + " in " + c.getName());
    }

    public void markAttendance(int studentId, int courseId, boolean present) {
        Student s = students.get(studentId);
        if (s == null) {
            System.out.println("Student not found.");
            return;
        }
        s.markAttendance(courseId, present);
        System.out.println("Marked attendance for " + s.getName() + " in course " + courseId + " -> " + (present ? "Present" : "Absent"));
    }

    public void listStudents() {
        if (students.isEmpty()) { System.out.println("No students."); return; }
        students.values().forEach(System.out::println);
    }

    public void listStudentsDetailed() {
        if (students.isEmpty()) { System.out.println("No students."); return; }
        for (Student s : students.values()) {
            System.out.println(s);
            for (Course c : s.getCourses()) {
                System.out.println("  Course: " + c + " | Attendance: " + s.getAttendance(c.getId()));
            }
        }
    }

    public void saveData() {
        storage.save(students, courses);
    }

    public void loadData() {
        Map<Integer, Student> loadedStudents = storage.loadStudents();
        Map<Integer, Course> loadedCourses = storage.loadCourses();
        if (loadedStudents != null) this.students = loadedStudents;
        if (loadedCourses != null) this.courses = loadedCourses;
    }
}
