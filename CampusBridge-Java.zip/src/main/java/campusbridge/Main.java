package campusbridge;

import campusbridge.models.Student;
import campusbridge.models.Course;
import campusbridge.services.StudentManager;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        StudentManager manager = new StudentManager();
        manager.loadData(); // load from storage if exists
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n=== CampusBridge-Java Menu ===");
            System.out.println("1. Create student");
            System.out.println("2. Add course");
            System.out.println("3. Enroll student in course");
            System.out.println("4. Mark attendance for student");
            System.out.println("5. List students");
            System.out.println("6. Save & Exit");
            System.out.print("Enter choice: ");
            String choice = sc.nextLine();
            switch (choice) {
                case "1":
                    System.out.print("Student ID: ");
                    int id = Integer.parseInt(sc.nextLine());
                    System.out.print("Name: ");
                    String name = sc.nextLine();
                    manager.addStudent(new Student(id, name));
                    break;
                case "2":
                    System.out.print("Course ID: ");
                    int cid = Integer.parseInt(sc.nextLine());
                    System.out.print("Course Name: ");
                    String cname = sc.nextLine();
                    manager.addCourse(new Course(cid, cname));
                    break;
                case "3":
                    System.out.print("Student ID: ");
                    int sid = Integer.parseInt(sc.nextLine());
                    System.out.print("Course ID: ");
                    int enrollCid = Integer.parseInt(sc.nextLine());
                    manager.enrollStudentInCourse(sid, enrollCid);
                    break;
                case "4":
                    System.out.print("Student ID: ");
                    int asid = Integer.parseInt(sc.nextLine());
                    System.out.print("Course ID: ");
                    int acost = Integer.parseInt(sc.nextLine());
                    System.out.print("Present? (y/n): ");
                    String p = sc.nextLine();
                    boolean present = p.equalsIgnoreCase("y");
                    manager.markAttendance(asid, acost, present);
                    break;
                case "5":
                    manager.listStudentsDetailed();
                    break;
                case "6":
                    manager.saveData();
                    System.out.println("Saved. Exiting. Goodbye!");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
