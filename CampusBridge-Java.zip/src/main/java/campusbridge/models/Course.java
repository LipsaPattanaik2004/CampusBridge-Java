package campusbridge.models;

public class Course {
    private int id;
    private String name;
    public Course(int id, String name) { this.id = id; this.name = name; }
    public int getId() { return id; }
    public String getName() { return name; }
    @Override public String toString() { return id + " - " + name; }
    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Course)) return false;
        Course c = (Course) o;
        return this.id == c.id;
    }
    @Override public int hashCode() { return Integer.hashCode(id); }
}
