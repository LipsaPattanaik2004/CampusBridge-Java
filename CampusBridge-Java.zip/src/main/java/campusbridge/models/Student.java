package campusbridge.models;

import java.util.*;

public class Student {
    private int id;
    private String name;
    private List<Course> courses = new ArrayList<>();
    private Map<Integer, Integer> attendanceCount = new HashMap<>(); // courseId -> presents

    public Student(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public List<Course> getCourses() { return courses; }

    public void enroll(Course c) {
        if (!courses.contains(c)) {
            courses.add(c);
            attendanceCount.putIfAbsent(c.getId(), 0);
        }
    }

    public void markAttendance(int courseId, boolean present) {
        if (!attendanceCount.containsKey(courseId)) attendanceCount.put(courseId, 0);
        if (present) attendanceCount.put(courseId, attendanceCount.get(courseId) + 1);
    }

    public int getAttendance(int courseId) {
        return attendanceCount.getOrDefault(courseId, 0);
    }

    @Override
    public String toString() {
        return id + " - " + name + " | Enrolled: " + courses.size();
    }
}
