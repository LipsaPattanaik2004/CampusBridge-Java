# SRS - CampusBridge-Java

## Overview
CampusBridge-Java is a console-based student management system demonstrating OOP, CRUD, and basic persistence.

## Functional Requirements
1. Create student (id, name)
2. Create course (id, name)
3. Enroll student in course
4. Mark attendance (studentId, courseId, present/absent)
5. List students with enrolled courses and attendance counts
6. Save and load data

## Non-Functional
- Data persistence using Java serialization
- Simple CLI interface
- Modularity and clear package separation

## Test Cases
- Add student -> List students
- Add course -> Enroll -> Mark attendance -> Verify attendance count
- Save, restart app, load -> Data persists
